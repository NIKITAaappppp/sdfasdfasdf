
  # Test Page for Vercel

  This is a code bundle for Test Page for Vercel. The original project is available at https://www.figma.com/design/KHOlpScx7VmRytaTzB6kst/Test-Page-for-Vercel.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  